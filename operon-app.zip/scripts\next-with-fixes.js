'use strict';

require('next/dist/bin/next');
