operon-logo.jpg added per request
